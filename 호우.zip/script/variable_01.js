let temp = 20.5;
const name = "현재온도는 ${temp} 입니다";

console.log(name);