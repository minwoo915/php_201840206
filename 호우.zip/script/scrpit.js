//document.write("hello world");
console.log("Hello world");
//alert("반갑습니다");