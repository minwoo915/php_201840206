
var ff = function()
{
    console.log("안녕하세요");
}

ff();