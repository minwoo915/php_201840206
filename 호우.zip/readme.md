## 안녕하세요
저는 대림대학교 김민우 입니다.

<a href = "abc">여기로 이동</a>

```php
<?php
$abc = "머림이";
$name = "abc";

echo $abc; //2번째 줄
echo ${$name}; // 3번째 줄
```