<?php
$arr = ['apple'=>"키위", 'banana'=>"티샤쓰"];
print_r($arr);

$str = json_encode($arr);
echo $str;