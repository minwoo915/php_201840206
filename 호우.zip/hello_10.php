<?php

print "안녕하세요. <br>";
print "대림대학교 입니다. <br>";