<?php

namespace minwoo\daelim;

class aaa
{
    public function hello()
    {
        echo "안녕";
    }
}