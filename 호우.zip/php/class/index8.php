<?php

include "index7.php";

use \minwoo\daelim\aaa;

$obj = new aaa;
$obj->hello();