<?php

$a = 1;
echo $a.">";

$a = $a + 1;
echo $a.">";

$a = $a + 1;
echo $a.">";

$a += 1;
echo $a.">";

$a += 1;
echo $a.">";

$a++;
echo $a.">";

$a++;
echo $a.">";

echo "\n";

$a--;
echo $a.">";

$a--;
echo $a.">";

echo "\n";
echo $a--.">";
echo $a--.">";