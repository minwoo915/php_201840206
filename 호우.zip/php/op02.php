<?php

echo intval(5/2)."\n";
echo (5%2);