<?php
include "../hello_10.php";
include "../hello_10.php";
echo "반갑습니다.<br>";
include "../hello_10.php";

require "./hello/hello_12.php";
require "./hello/hello_12.php";
require "./hello/hello_12.php";
