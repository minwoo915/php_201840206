<?php
$temp = 20.5;
$name = `현재 온도는 $temp 입니다.`;

echo $name;