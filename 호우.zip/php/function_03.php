<?php
// 선언
function hello()
{
    // 함수의 내용
    echo "안녕하세요.";
}

// 함수 호출
hello();

$fff = "hello";
$fff();