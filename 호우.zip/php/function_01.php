<?php

$name = "머림이";

// 선언
if(!function_exists("hello")){
    function hello()
    {
        echo "반가와요 ";
    }
}

// 호출
hello();
hello();