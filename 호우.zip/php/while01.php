<?php
$conf = true;
$i = 0;
while($conf){
    echo"바보야\n";
    $i++;
    if($i>5) $conf = false;
}