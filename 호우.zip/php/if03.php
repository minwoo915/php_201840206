<?php

$lang = "ko";
$title = ($lang == "ko")? "한국어" : "korean";
echo $title;