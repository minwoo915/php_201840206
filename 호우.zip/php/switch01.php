<?php

$n =1;

switch($n) {
    case 1:
        echo "하나";
        break;
    case 2:
        echo "둘";
        break;
    default:
    echo "셋";
}

echo "끝";