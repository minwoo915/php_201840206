<?php

trait MyName
{
    echo "안녕";
}
?>