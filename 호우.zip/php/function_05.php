<?php

//
$ff = function()
{
    // 함수의 내용
    echo "안녕하세요";
};

//
$ff();