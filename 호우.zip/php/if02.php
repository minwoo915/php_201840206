<?php
$sex = "man";
$age = 19;
if ($sex == "man" && $age >= 19){
    echo "남자 성인 입니다.";
}