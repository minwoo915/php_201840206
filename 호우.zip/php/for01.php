<?php

$i=0;
for (;$i<5;){
    echo $i."너는 바보야 \n";
    $i++;

    if($i==2){
        echo "아니야";
        break;
    }
}