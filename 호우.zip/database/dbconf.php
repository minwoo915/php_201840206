<?php

// 서버정보

$host = "localhost";
$user = "phpuser";
$passwd = "multi1004";
$database = "php";

return ["host"=>$host, "user"=>$user, "passwd"=>$passwd, "database"=>$database];